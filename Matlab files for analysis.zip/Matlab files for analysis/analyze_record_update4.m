%analyze_record_update4 analyzes data for generating figures S2-S5.
%
%It generates the following data:
%cor1 - this is the correlation between (P_1^x E^x) (i.e., sp. 1's
%  reproductive rate at each site) and (P_0^x E^x) (i.e., the same for the
%  cheater).
%cor2 - Same as cor1, but for species 2.
%fdCovAA1- This is the covariance between the density of resource 2 and
%  species 1's relative density (i.e., N_1/mean(N_1)).  It tells you how much
%  a microbe's access to resource 2 will change if you move it to a random
%  spot, on average.
%fdCovAA2- This is the same, but for resource 1 and species 2.
%fdCovAA0- This is the same, but for the cheater, and whichever is the
%  rarer resource at the site.
%fDiff- This tells you how much the cheater's resource uptake is reduced below
%  the average cross-feeder (on average across all sites).
%birth1- This tells the mean resource uptake for species 1 (averaged across
%  all sites).
%birth2- The same for species 2.
%birth0- The same for the cheater.
%birth1s- Same as birth1, but after the community has been randomly
%  rearranged.
%birth2s- Same but for species 2.
%birth0s- Same but for the cheater.


[a b]=size(NN);

if(a==b)
    SIZE=a;
    NN=reshape(NN,1,SIZE^2);
else
    SIZE=max(a,b)^(1/2);
end

%NN=reshape(N1,1,SIZE^2);
%NN(randperm(SIZE^2))=NN;

%neighborAA is as SIZE x ((2*n2dist+1)^2-1) matrix.  When it is contructed,
%then sum((NN(neighborAA)==1),1) will tell you how many sites within n2dist
%are equal to 1.  This is used for calculating the amount of resources that
%go to each site.
neighborAA=construct_neighbor_mat(double(SIZE),double(n2dist));

%neighborE is similar to neighborAA, but for empty sites.
neighborE=construct_neighbor_mat(double(SIZE),double(ndist));

%This is the area that resources diffuse over, and that microbes can
%disperse over.
n_areaAA=(2*n2dist+1)^2-1;
n_areaE=(2*ndist+1)^2-1;

%This is average number of each microbe.
nbar=[mean(mean(NN==1)) mean(mean(NN==2)) mean(mean(NN==3))];

%This is the amout of resource 2 at each site.
AA2 = sum((NN(neighborAA)==3),1)/n_areaAA*K;

%now I do the same thing for AA1.
AA1 = sum((NN(neighborAA)==2),1)/n_areaAA*K;

%This tells the cheater's resource uptake at each site.
f0=min(AA1,AA2);

%e is a list of all of the empty sites.
e = (NN==0);
%This tells E^x at each site
nearbyE = sum((NN(neighborE)==0),1)/n_areaE;

%ebar is the mean fraction of sites that are empty.
ebar=mean(mean(e));

%if a site is occupied, aa_at_e is 0.  Otherwise, it is f(AA).
%Together, this gives the chance of reproducing into that area.
lambda1 = 1+AA2.*nearbyE*bs-d;
lambda2 = 1+AA1.*nearbyE*bs-d;
lambda0 = 1+f0.*nearbyE*b0-d;

lambdaBar1=mean(lambda1);
lambdaBar2=mean(lambda2);
lambdaBar0=mean(lambda0);

birth1=mean(AA2);
birth2=mean(AA1);
birth0=mean(f0);

l1=AA2*bs;
l2=AA1*bs;
l0=f0*b0;

oneHere=(l1>l2);
twoHere=(l1<l2);
theSame=(l1==l2);

crossWinAll=(max(l1,l2)>l0).*(-oneHere+twoHere);
darkCompAll=(((l1+l2)/2)>l0).*(-oneHere+twoHere);
%lightCompAll=(crossWinAll-abs(darkCompAll)).*(-oneHere+twoHere);
sameCompAll=(max(l1,l2)==l0);

crossWin=mean(abs(crossWinAll));
darkComp=mean(abs(darkCompAll));
sameComp=mean(abs(sameCompAll));
lightComp=crossWin-darkComp;

covEC1=(mean(mean(nearbyE.*AA2))-mean(mean(AA2))*ebar);
covEC2=(mean(mean(nearbyE.*AA1))-mean(mean(AA1))*ebar);
covEC0=(mean(mean(nearbyE.*f0))-mean(mean(f0))*ebar);

covECdif=covEC0-(covEC1+covEC2)/2;
fDiff=ebar*(mean(mean(f0))-mean(mean(AA1+AA2))/2);

fdCov1=sum(lambda1.*(NN==2))./(nbar(2)*SIZE^2)-mean(mean(lambda1));
fdCov2=sum(lambda2.*(NN==3))./(nbar(3)*SIZE^2)-mean(mean(lambda2));
fdCov0=sum(lambda0.*(NN==1))./(nbar(1)*SIZE^2)-mean(mean(lambda0));


fdCovAA1=sum(l1/bs.*(NN==2))./(nbar(2)*SIZE^2)-birth1;
fdCovAA2=sum(l2/bs.*(NN==3))./(nbar(3)*SIZE^2)-birth2;
fdCovAA0=sum(l0/b0.*(NN==1))./(nbar(1)*SIZE^2)-birth0;

cor1=corr(AA2',f0');
cor2=corr(AA1',f0');
corAlt=corr(AA1'+AA2',f0');

if(~exist('SHAKEITUP'))
    SHAKEITUP=0;
end

if(SHAKEITUP)
    %If you set SHAKEITUP to 1 (or some non-zero number), then I
    %randomly rearrange the data, and rerun some of my calculations.
    
    Nshake(randperm(SIZE^2))=NN;
    
    
    %This calculates the density of resource 2 at each site.
    AA2 = sum((Nshake(neighborAA)==3),1)/n_areaAA*K;
    
    %This calculates the density of resource 1 at each site.
    AA1 = sum((Nshake(neighborAA)==2),1)/n_areaAA*K;
    
    %This calculates what the cheater's uptake will be at each site.
    f0=min(AA1,AA2);
    
    %e is a list of all of the empty sites.
    e = (Nshake==0);
    %nearbyE = reshape(sum((NN(neighbor)==0),1)/n_area, Nshape);
    nearbyE = sum((Nshake(neighborE)==0),1)/n_areaE;
    
    %ebar is the mean fraction of sites that are empty.
    ebar=mean(mean(e));
    
    %if a site is occupied, aa_at_e is 0.  Otherwise, it is f(AA).
    %Together, this gives the chance of reproducing into that area.
    lambda1shake = 1+AA2.*nearbyE*bs-d;
    lambda2shake = 1+AA1.*nearbyE*bs-d;
    lambda0shake = 1+f0.*nearbyE*b0-d;
    
    lambdaBar1shake=mean(lambda1shake);
    lambdaBar2shake=mean(lambda2shake);
    lambdaBar0shake=mean(lambda0shake);
    
    birth1shake=mean(AA2);
    birth2shake=mean(AA1);
    birth0shake=mean(f0);
end

