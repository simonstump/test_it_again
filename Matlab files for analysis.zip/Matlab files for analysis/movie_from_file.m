%movie_from_file makes a movie from a simulation.  To do this, you will
%first need to run parallel_boomAndBust.  You can either generate
%a movie from a simulation that you ran, or you can do it from a saved
%file.
%
%Critically, to make a movie, you need a variable called 'record' that is
%an NxNxTIME matrix, with entries between 0 and 3.  A point (1,3,20)
%indicates who resides at the point (1,3) at time 20.  It is 0 if empty, 1
%if a cheater, and 2 or 3 if a cross-feeder.  Either those values need to
%be pre-loadad, or you need to load them as part of the program.


%load('20170130BoomBust_Ad9_Ac7.mat')
clear M  %M will be the name of the movie file.

%movname is the name of the movie file that will be saved.  Basically, with
%this if statement, I set it to the default value of 'moviename' if you
%have not given it one.
%
%WARNING: There is nothing to stop you from overwriting previous movie
%files if you give them the same name.
if(exist('movname')==0)
    movname='moviename';
end

M=VideoWriter([movname, '.avi']);
open(M);

axis tight
set(gca,'nextplot','replacechildren');


framenum=1; %tracks which frame we are on.

TIME=length(record);

%The for loop runs through each time step (or, right now, every 3rd time
%step).  At each time step, it plots the distribution of each microbe.
for t = 1:3:TIME%:ceil(TIME/2)
    t
    %N becomes the distribution of each species at time t.
    N=record(:,:,t)';
    
    clf
    
    %theM sets the size of each dot.
    theM=6;
    spy(N==2,'b.',theM)
    hold on
    spy(N==3,'g.',theM)
    spy(N==1,'m.',theM)
    hold off
    title(['t = ',num2str(t)])  %this records the time
    
    framenum=getframe;
    %here I save the current graph to my movie file, M.
    writeVideo(M,framenum);
    
    
end

 
%This saves the movie as an .avi file.  They tend to be super big.
%However, if you open them on a Mac, it will turn them into a QuickTime
%file and compress them greatly.
close(M)
%VideoWriter(M, [movname, '.avi'], 'compression', 'None')
