function out = construct_neighbor_mat(SIZE,n_dist)

%construct_neighbor_mat(SIZE, n_dist) creates an Nx(SIZE)^2 matrix, where
%each column is a list of all of neighbors that are within n_dist of each
%cell in a SIZExSIZE square matrix.
%
%SIZE is the length or width of the square area.
%n_dist in the number of nearby neighbors.
%
%I use this later to determine the values of all of the neigbors of each
%cell in N.  For example, if N is a matrix, and neighbor is the output of
%constuct_neighbor_mat, then the command
%reshape(sum(N(neighbor)==8, 1), size(N))
%will cerate a matrix the same size as N, where each entry is the number of
%neighbors that have the value 8.

matSize = SIZE^2;

%offset defines how far away each neighbor is.  For example, the neighbor
%above is at -1, and the neighbor to the right is at +SIZE.  This will
%later be added to each entry in the matrix to give a matrix with all of
%the neighbors.
offset=[];

%Here I add in neighbor distances one row at a time, from those nearby to
%those on the outside (with the outside ones placed in the front of the
%matrix.
for i=1:n_dist
    
    %These are the neighbors that are i above the focal cell.
    offset = [(i+SIZE*(-n_dist:n_dist)) offset];

    %These are the neighbors that are i below the focal cell.
    offset = [(-i+SIZE*(-n_dist:n_dist)) offset ];
    
end

%These are the neighbors on the same row as the focal cell.
offset = [offset (SIZE*(-n_dist:n_dist))];

%This removes the focal cell from the average.
offset(offset==0) = [];

%makes a matrix, with each column the value of the 8 neighbor cells.
out = bsxfun(@plus, (1:matSize), offset(:));

%below I correct for the edge cases
%
%if you are jumping from the bottom to the top, or vice-versa, then I
%need to add or subtract the size (e.g., in a 5x5 matrix, if you are on
%the bottom row, your neighbor below is 5 less than you, rather than 1
%more).

correction=zeros((2*n_dist+1)^2-1,SIZE);

%Basically, if you are j from the top, then your (n_dist - j) above
%neighbors will be below you, and we need to correct for this edge.
%Similarly, if you are j from the bottom, then your (n_dist - j) below
%neighbors are above you.  Below I create a loop that makes a matrix of
%this for the first column.
for i=1:n_dist
    
    kk=(2*n_dist+1);
    for j=0:(n_dist-i)
        
        correction((2*j*kk+1):(2*j*kk+kk),i)=SIZE;
        correction((2*j*kk+kk+1):(2*j*kk+2*kk),SIZE+1-i)=-SIZE;
        
    end
    
end

%Then, I repeat the matrix for every column.
cor2=repmat(correction,1,SIZE);

out=out+cor2;


%here I correct for negative numbers, or numbers that are bigger than
%the size of the matrix.
out=mod(out,matSize);

out=out+(out==0)*matSize;




%here I correct for negative numbers, or numbers that are bigger than
%the size of the matrix.
out=mod(out,matSize);

out=out+(out==0)*matSize;

