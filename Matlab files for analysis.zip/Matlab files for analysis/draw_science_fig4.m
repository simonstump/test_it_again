%The function draw_science_fig4.m will generate the data for figure 4.  It
%requires output from the R function parallel_boomAndBust, which is loaded
%at the beginning of the file.  It saves the figures as 3 pdfs.


close all

%Here we load the data from the simulation.
%load('20170130BoomBust_Ad9_Ac7')
%load('20170130BoomBust_Ad25_Ac3')
load('20170130BoomBust_Ad3_Ac15a')

%name should be a string, which will be attached to every figure that this
%program generates.
name='neighbor_uncert2';

%To track population fluctuations, we look at population density in a
%blockSize x blockSize box.
blockSize=50;

%Set isLeg = 1 to put a legend on the population dynamics diagram
%(like in Fig. 4C).  Set it to 0 to not have a legend (like Fig. 4F).
isLeg=1;

%AXISSIZE determines how much of the community you see.
AXISSIZE=[1 200 001 200];

%This sets where the block is that population density is tracked over.
rangeX=[1:blockSize];
rangeY=[(1+AXISSIZE(4)-blockSize):AXISSIZE(4)];

[xmax,ymax,TIME]=size(record);

%In my figures, I decided to track population dynamics for only a
%certain amount of time.  If you want it to plot the entire simulation, and
%show the population dynamics on the last step, then comment this out.
%TIME=3440%TIME-100;

%pops calculates the density of each microbe in the box over time.
pops=zeros(3,TIME-1);

%Nsmall is a subset of the data in record (which should be an X x Y x Z
%matrix, where record(x,y,z) tells you who is occupying site (x,y) at time
%z).  Nsmall is record, but only in the box that we are tracking population
%dynamics over.
Nsmall=record(rangeX,rangeY,1:TIME);



%%%%%%%%%%%%%%%
%First, we plot the population density of each microbe in the black box
%over time (e.g., Fig. 4C).
%%%%%%%%%%%%%%%


%In this for loop, I determine the values of pops (i.e., the mean density
%of each microbe in the box).
for(i=2:TIME)
    
    here=Nsmall(:,:,i)';
    
    pops(:,i-1)=[(mean(mean(here==2))), (mean(mean(here==3))), ...
        (mean(mean(here==1)))];

end

%Here I plot the population dynamis figure (e.g., Fig 4C).

figA=figure();
plot([1:TIME-1],pops(2,:),'b-',[1:TIME-1],pops(1,:),'g-',...
    [1:TIME-1],pops(3,:),'m-','linewidth',1)

xlabel('Time, $t$','interpreter','latex');
ylabel('Density in subsection, $\overline{N_j}$','interpreter','latex');

if(isLeg)
l=legend('Species 1',...
    'Species 2',...
    'Cheater',...
    ...%'sp. $\overline{N_0}$',...
    'Location','NorthEast');
set(l,'Interpreter','latex');
end

axis([0, TIME, 0, .6])


set(gca,'fontsize', 16);

set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['density_',name,'.pdf'])

figA=figure();

%%%%%%%%%%%%%%%
%Next, we plot the distribution of microbes in the community at time TIME
%(e.g., Fig. 4A).
%%%%%%%%%%%%%%%

%N1t is a snapshot of the community at time TIME.
%for aesthetic reasons, I shifted the matrix by 90 degrees for my figures
%(basically, I wanted the stripes in the pattern formation graph to be
%horizontal, so they were easier for the reader to compare to Fig 4D and
%4E).
N1t=record(:,:,TIME)';

%Basically, col and row are matrices that repeat the numbers 1 through 200.
%I use these to generate the X and Y values for where each microbe can be
%found.
col=repmat([200:-1:1]',1,200);
row=repmat([1:200],200,1);

%theM sets the sizes of the dots.
theM=7;

%Basically, AADif1 is a matrix of 0s and 1s.  It is 1 if the site is
%occupied by species 1 (i.e., if the entry equals 2), and 0 otherwise.
AADif1=(N1t==2);
%x will be a matrix with many 0's, and many numbers 1 to 200.  If a
%variable is not 0, then it means that there is a species 1 microbe at that
%x-coordinate (the y-coordinate is in the y matrix).  This matrix generates
%a lot of values at (0,0), which the user will not see if they correctly
%set the x and y axis to not include (0,0) (this is kind of a hack, but
%saves time).
x=row.*AADif1;
%y is similar to x, but for y coordinates.
y=col.*AADif1;
%now I plot x and y.  Basically, if x(j) ~= 0 for some j, then y(j) will
%also not be 0.  
plot(x,y,'.','Color',[0  1  0],'MarkerSize',theM)


%I then do this again for species 2.
hold on

AADif1=(N1t==3);
x=row.*AADif1;
y=col.*AADif1;
plot(x,y,'.','Color',[0  0  1],'MarkerSize',theM)

%I then do it again for the cheater.
AADif1=(N1t==1);
x=row.*AADif1;
y=col.*AADif1;
plot(x,y,'r.','Color',[1  .5  1],'MarkerSize',theM)

%This is where I draw the black box.
x1=rangeX(1);
x2=rangeX(length(rangeX));
y1=rangeY(1);
y2=rangeY(length(rangeY));
t1=[x1 x1 x2 x2 x1];
t2=[y1 y2 y2 y1 y1];
plot(t1,t2,'w-',t1,t2,'k--','linewidth',3)

hold off

axis(AXISSIZE)

set(gca,'visible','off')
axis square

set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['popLoc_',name,'.pdf'])


%%%%%%%%%%%%%%%
%Finally, we plot the density of each compound at time TIME (e.g., Fig.
%4B).
%%%%%%%%%%%%%%%


figA=figure();

NN=N1t;

%ALT=1;

%neighborAA is a SIZE x ((r_res+1)^2-1) matrix.  Basically, if we calculate
%sum((NN(neighborAA)==2),1), then it will give us a matrix, where each site
%tells us the number of microbes within A_res sites that are species 1.
neighborAA=construct_neighbor_mat(double(SIZE),double(n2dist));

%n_areaAA is the number of sites that are within r_res.  
n_areaAA=(2*n2dist+1)^2-1;

%AA2t tells the density of resources 2 at each site.
%(K is actually the quantity of resources produced, it was Q in the main
%text).
AA2t = sum((NN(neighborAA)==3),1)/n_areaAA*K;

%if(ALT==1)

%The program gets buggy if AA2t can be 0 in places, so if it is, then we
%set the value at that site to 10^-4.
    AA2= max(AA2t,ones(1,SIZE^2)*.0001);
%else
%    AA2 = min(AA2t,ones(1,SIZE^2));
%end

%This makes it the correct shape.
AA2=reshape(AA2,SIZE,SIZE);

%We then do teh same thing for resouce 1.
AA1t = sum((NN(neighborAA)==2),1)/n_areaAA*K;

%if(ALT==1)
    AA1= max(AA1t,ones(1,SIZE^2)*.0001);
%else
%    AA1 = min(AA1t,ones(1,SIZE^2));
%end

AA1=reshape(AA1,SIZE,SIZE);

%if(withDie)
%    DieOut=max(min(AA1,AA2)*.7<.15,max(AA1,AA2)*.6<.15);
%else
%    DieOut=AA1*0;%max(min(AA1,AA2)*.7<.15,max(AA1,AA2)*.6<.15);
%end


%AADif calculates how different the resources densities are at each site.
AADif=(max(AA1,AA2)./min(AA1,AA2)-1).*(2*(AA2>AA1)-1);

AADif=reshape(AADif,SIZE,SIZE);

%AADif=AADif.*(1-DieOut);

%We then do something similar to before.  Basically, we figure out where
%AADif is really small (e.g., where there is way more of resource 2), and
%put a dark green dot in those areas, using the same method we used to place
%microbes.  We then put in dark blue dots, and so on.  
col=repmat([200:-1:1]',1,200);
row=repmat([1:200],200,1);


AADif1=(AADif>.17);
x=row.*AADif1;
y=col.*AADif1;
plot(x,y,'.','Color',[0.7  0.7  1],'MarkerSize',theM)


hold on

AADif1=(AADif<-.17);
x=row.*AADif1;
y=col.*AADif1;
plot(x,y,'y.','Color',[.5  1  .5],'MarkerSize',theM)

AADif1=(AADif>.34);
x=row.*AADif1;
y=col.*AADif1;
plot(x,y,'.','Color',[0  0  1],'MarkerSize',theM)

AADif1=(AADif<-.34);
x=row.*AADif1;
y=col.*AADif1;
plot(x,y,'r.','Color',[0  .8  0],'MarkerSize',theM)

%AADif1=(DieOut);
%x=row.*AADif1;
%y=col.*AADif1;
%plot(x,y,'k.','Color',[.1  .1  .1],'MarkerSize',theM)

hold off
axis(AXISSIZE)

set(gca,'visible','off')
axis square

set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,['res_',name,'.pdf'])
