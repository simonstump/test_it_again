function figA = myheatmap(values,X,Y,minV,maxV)

%myheatmap(values,X,Y,minV,maxV)
%
%This program generates heat-map digrams, like Fig. S2-S5.  
%
%values gives the value of the thing we want to draw the heatmap of.
%X and Y are the r_mic and r_res values corresponding to each number in
%values.
%minV and maxV tells what values to consider.  For example, if minV=0 and
%maxV = 1, then any value higher than 1 is colored the same shade of black
%as 1, and any value lower than 0 is colored the same shade of white as 0.
%
%Right now it is set specifically for 200x200 communities.  If you want to
%change this, you will need to change the variable SIZE, and alter the axis
%used at the end.  

values=reshape(values,numel(values),1);
X=reshape(X,numel(X),1);
Y=reshape(Y,numel(Y),1);

figA=figure();

%SIZE is the size of each community used.
SIZE=200;
%ADJ is how much space to put between each community.  If ADJ=1, then every
%community will be squished together with no white edge separating them.
%If ADJ=1.05, then there will be a space between them that is 5% of the
%size of a community.
ADJ=1.05;

bigGrid=zeros((15+1)/2*SIZE*ADJ-SIZE*(ADJ-1),...
    (25+1)/2*SIZE*ADJ-SIZE*(ADJ-1));

[x,y]=size(bigGrid);

spy(bigGrid,'w.')

col=repmat([x:-1:1]',1,y);
row=repmat([1:y],x,1);

hold on

theM=3;


for i=1:length(values)
    
    if(isnan(values(i)))
        %here I draw an X in any diagram that does not contain information.
        N1=1;
        N2=0;
        
        ndist=Y(i);
        n2dist=X(i);
        
        theY1=x-[ADJ*SIZE*(ndist-1)/2+1];
        theY2=x-[ADJ*SIZE*(ndist-1)/2+SIZE];
        
        theX1=[ADJ*SIZE*(n2dist-1)/2+1];
        theX2=[ADJ*SIZE*(n2dist-1)/2+SIZE]';
        
        plot([theX1,theX2],[theY1,theY2],'k-',...
            [theX1,theX2],[theY2,theY1],'k-')
        
        
        %values(i)
        %'is NaN'
    else
        %Here I draw a shaded box in any area that has a value.
        
        %N1=max(maxV-max(values(i),minV),0)/(maxV-minV)
        N1=1-max(0,min(1,(values(i)-minV)/(maxV-minV)));
        N2=N1;
        
        ndist=Y(i);
        n2dist=X(i);
        
        theY=x-[ADJ*SIZE*(ndist-1)/2+1:ADJ*SIZE*(ndist-1)/2+SIZE];
        theY=repmat(theY,SIZE,1);
        
        theX=[ADJ*SIZE*(n2dist-1)/2+1:ADJ*SIZE*(n2dist-1)/2+SIZE]';
        theX=repmat(theX,1,SIZE);
        
        %[N N N]
        
        plot(theX,theY,'Color',[N1  N2  N2],'MarkerSize',theM)
    end
    
    
end
hold off


axis([-6 2723 -5 1674])

set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
%saveas(figA,'heatmap.pdf')
