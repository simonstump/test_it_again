function myheatmap_save(values,X,Y,minV,maxV,name)

%myheatmap_save(values,X,Y,minV,maxV,name)
%
%This function runs myheatmap and saves the data.  It could be used to
%generate figures S2-S5.

figA=myheatmap(values,X,Y,minV,maxV);

set(gca,'xtick',[])
set(gca,'xticklabel',[])
set(gca,'ytick',[])
set(gca,'yticklabel',[])

set(figA,'Units','Inches');
pos = get(figA,'Position');
set(figA,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(figA,[name,'.pdf'])
