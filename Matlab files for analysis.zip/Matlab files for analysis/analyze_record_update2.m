%analyze_record_update replaces analyze_record_full for the newer model.
%It takes in a set of data (record and others), and
%calculates a number of parameters about the population growth rate.
%Specifically, it outputs an array (called 'the_results') with the following
%the_results(1)= the average fraction of empty sites.
%the_results(2)= the mean value of f_j(C) (i.e., mean compound limitation)
%the_results(3)= min(mean(AA)) (i.e., the mean level of the most limiting
%compound).
%the_results(4)= the difference between 3 and 2 (i.e., how much sp. n is
%limited by compounds).
%the_results(5)= the covariance beteen E and f(AA) across sites.
%the_results(6)= the fitness-density covariance.
%the_results(7)= the covariance between relative density and E.
%the_results(8)= the covariance between relative density and f(AA).
%the_results(9 and 10)= two covariances between E and f(AA).
%
%This program also outputs 2 dimensional matrix called 'results' which
%calculates each of these things over several time steps.  the_results is
%the average of these values.
%
%I don't look at the entire time period, but rather I start a a time called
%MINTIME (which needs to be supplied externally).  I go until the end of
%the simulation (TIME, also supplied externally).
%
%analyze_record_full requires that an invader (INV) be named, but then
%fully analyzes everything that would come from the original analyze_record
%(unlike previous versions, which were built for a particular invader).

[a b L] = size(record);

%MINTIME=200;
results = zeros(TIME-MINTIME+1,9);
results_var = zeros(TIME-MINTIME+1,9);


%Here I figure ot which AA's the invader needs.
needAA1=0;
needAA2=0;

switch(INV)
    case 1
        'N12'
    case 2
        'N2'
        needAA1=1;
    case 3
        'N_1'
        needAA2=1;
    case 4
        'N0'
        needAA1 = 1;
        needAA2 = 1;
    otherwise
        'error'
        error()
end

%each AA is the number of AA's at a given site.
AA1=ones(1,SIZE^2);
AA2=ones(1,SIZE^2);

%I have this if statement so that if a population goes extinct, everything
%is set to NaN (since some of these things will be NaN anyway).  This
%speeds up analysis.  Basically, the if is "If some species persisted to
%the end"
if(mean(mean(record(:,:,TIME)==0))<1)
    
    %This for loop goes through every time step.
    for i = MINTIME:TIME
        
        %This is a snapshot of the environment at time i.
        NN=record(:,:,i);
        
        %nbar is the average density of our species of interest (INV).
        nbar = mean(mean(NN==INV));
        
        %I use the following numbers for species:
        %1- N12, 2- N2, 3- N1, 4-N0
        
        %fAA eventually becomes compound limitation at each site.  It is
        %set to the minimum of 1 and the lowest AA.
        %fAA=ones(SIZE);
        fAA=ones(1,SIZE^2);
        
        %if the species needs AA1, then fAA at each site is set to the
        %minimum of 1 and AA1 at that site.
        if(needAA1)
            %This calculates the number of AA1's that goes to each site.
            %neighbor is a list of all of the neighbors at each site.
            %Thus, for example, sum(NN(neighbor)==1)) is the total number
            %of neighboring sites that equal 1.  This whole thing ends up
            %being the sum of the species that produce AA1, divided by the
            %number of sites (n_area), times the amoutn of AA1 each
            %individual produces (K).
            %AA1 = reshape(sum((NN(neighbor)==1)+(NN(neighbor)==2)+...
            %    (NN(neighbor)==3)+(NN(neighbor)==5),1)/n_area, Nshape)*K;
            AA1 = sum((NN(neighborAA)==1)+(NN(neighborAA)==3),1)/n_areaAA*K;
            fAA=min(fAA,AA1);
        end
        %now I do the same thing for AA2.
        if(needAA2)
            %AA2 = reshape(sum((NN(neighbor)==1)+(NN(neighbor)==2)+...
            %    (NN(neighbor)==4)+(NN(neighbor)==6),1)/n_area, Nshape)*K;
            AA2 = sum((NN(neighborAA)==1)+(NN(neighborAA)==2),1)/n_areaAA*K;
            fAA=min(fAA,AA2);
        end
        
        
        %AAbar is what f(AA) is in the mean-field case.
        %AAbar = min(mean(mean(AA3)),...
        %    min(mean(mean(AA2)),...
        %    min(mean(mean(AA1)),1)));
        AAbar = min(mean(AA2),min(mean(AA1),1));
        
        
        %meanFAA is the mean of fAA.  It is the average compound
        %limitation.
        %meanFAA=mean(mean(fAA));
        meanFAA=mean(fAA);
        
        %f_limit is the amount that E[f(AA)] is reduced because of
        %variation in AA density.
        f_limit = meanFAA-AAbar;
        
        %e is a list of all of the empty sites.
        e = (NN==0);
        %nearbyE = reshape(sum((NN(neighbor)==0),1)/n_area, Nshape);
        nearbyE = sum((NN(neighborE)==0),1)/n_areaE;
        
        %ebar is the mean fraction of sites that are empty.
        ebar=mean(mean(e));
        
        %if a site is occupied, aa_at_e is 0.  Otherwise, it is f(AA).
        %Together, this gives the chance of reproducing into that area.
        lambda = fAA.*nearbyE;
        
        temp = cov(nearbyE,fAA);
        covEF = temp(2,1);
        
        
        %nu is the relative density (n/nbar) of the focal species around
        %the environment.
        %nu = (NN==INV)/(mean(mean(NN==INV)));
        nu = reshape((NN==INV),[1,SIZE^2])/(mean(mean(NN==INV)));
        
        %this is the full fitness-density covariance.  
        %FDcov = mean(mean(nu.*lambda))-mean(mean(nu))*mean(mean(lambda));
        FDcov = mean(nu.*lambda)-mean(nu)*mean(lambda);
        
        FD_e = mean(nu.*nearbyE)-mean(nu)*mean(nearbyE);
        FD_aa = mean(nu.*fAA)-mean(nu)*mean(fAA);
        FD_cov = FDcov - FD_e*mean(nearbyE) - FD_aa*mean(fAA);
        %FD_eacovglo = -(1-nbar)*(tempcov - tempcov2);
        
        
        
        
        %finally, I record everything.
        results(i-MINTIME+1,:) = [ebar meanFAA AAbar f_limit covEF FDcov ...
            FD_e FD_aa FD_cov];
        
        %%%%%%%%%%%%%%
        %Newer stuff, variance and cov stuff, and predictions
        %%%%%%%%%%%%%%
        
        temp = cov(AA1/K,AA2/K);
        
        varAA = (temp(1,1)+temp(2,2))/2;
        covAA = temp(1,2);
        
        meanN12=mean(mean(NN==1));
        meanN2=mean(mean(NN==2));
        meanN1=mean(mean(NN==3));
        meanAA=meanN12+(meanN1+meanN2)/2;
        
        varAA_expect = meanAA*(1-meanAA)/n_areaAA;
        covAA_expect = (meanN12*(1-meanN1-meanN2)-meanN1*meanN2-...
            meanN12^2)/n_areaAA;
        
        covEFexpected = -meanFAA*ebar/(max(n_areaE,n_areaAA));
        
        if(INV==2)
            fExp1=expected_f1(meanN1+meanN12,K,n_areaAA,1);
            fExp2=expected_f1(meanN1+meanN12,K,n_areaAA,varAA/varAA_expect);
        elseif(INV==3)
            fExp1=expected_f1(meanN2+meanN12,K,n_areaAA,1);
            fExp2=expected_f1(meanN2+meanN12,K,n_areaAA,varAA/varAA_expect);
        elseif(INV==4)
            if(meanN12>10^-4)
                cmod = (1-meanN12/((meanN2+meanN12)*(meanN12+meanN1)));
            else
                cmod=1;
            end
            fExp1=expected_f0(meanN1+meanN12,meanN2+meanN12,K,n_areaAA,1,cmod);
            fExp2=expected_f0(meanN1+meanN12,meanN2+meanN12,K,n_areaAA,...
                varAA/varAA_expect,cmod*covAA/covAA_expect);
            %meanFAA
            %pause
        elseif(INV==1)
            fExp1=1;
            fExp2=1;
        end
        
        results_var(i-MINTIME+1,:) = ...
            [varAA, covAA, varAA_expect, covAA_expect, covEF, covEFexpected, ...
            meanFAA, fExp1, fExp2];
        
    end
    
    the_results = mean(results,1);
    the_results_var = mean(results_var,1);
else
    %If everyone went extinct, then I set all values to NaN and print that
    %everyone went extinct.  
    'extinction'
    the_results = ones(1,9)*NaN;
    the_results_var = ones(1,9)*NaN;
end